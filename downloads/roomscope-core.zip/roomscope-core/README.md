# ROOM·SCOPE — DSP-ядро

Личный проект: AR-калибратор акустики помещения. Очки — рулетка координат,
UMIK-1 — ухо, MacBook — мозг. См. дорожную карту (`roomscoperoadmap.html`)
для полного контекста фаз разработки.

## Статус (Фаза 0 — DSP-ядро на Mac)

- `dsp/swept_sine.py` — генерация логарифмического swept sine ✅
- `dsp/impulse_response.py` — деконволюция IR методом Farina ✅
- `dsp/octave_smoothing.py` — 1/3-октавное сглаживание АЧХ ✅
- `dsp/peq_calculator.py` — автопоиск проблемных частот и расчёт PEQ ✅
- `measurement.py` — модуль реального измерения (sweep + запись) ✅ новое
- `compare_profiles.py` — сравнение A/B: подвинул колонку — сравнил профили ✅ новое
- `tests/test_dsp.py` — базовые unit-тесты ✅ новое

## Установка

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install numpy scipy soundfile sounddevice matplotlib pytest
```

## Использование

Синтетический прогон всего пайплайна (без UMIK-1):

```bash
python measurement.py                       # sweep + синтетическая "запись" комнаты
python -m dsp.impulse_response               # деконволюция IR
python -m dsp.octave_smoothing                # АЧХ 1/3 октавы + график
python -m dsp.peq_calculator                  # автопоиск пиков и PEQ -> profile.json
```

Когда приедет UMIK-1:

1. `python measurement.py --list-devices` — найти индекс микрофона в списке.
2. В `config.json` поставить `"mode": "real"` и `"input_device": <индекс>`.
3. `python measurement.py` — теперь пишет реальную комнату вместо синтетики.

### A/B — подвинул колонку, сравнил

Рабочий цикл ровно такой, каким его хочется видеть в очках, но уже доступен
на голом ноутбуке + UMIK-1:

```bash
# 1. замер в текущей расстановке (пишет test_sweep.wav + room_A.wav)
python measurement.py --out room_A.wav
python -m dsp.impulse_response --recording room_A.wav --out ir_A.wav
python -m dsp.peq_calculator --ir ir_A.wav --out profiles/seatA_default.json --label "seat A / default"

# 2. подвинул колонку, замерил снова
python measurement.py --out room_B.wav
python -m dsp.impulse_response --recording room_B.wav --out ir_B.wav
python -m dsp.peq_calculator --ir ir_B.wav --out profiles/seatA_moved18cm.json --label "seat A / +18cm от стены"

# 3. сравнил
python compare_profiles.py profiles/seatA_default.json profiles/seatA_moved18cm.json --plot profiles/compare_ab.png
```

На выходе — таблица по 1/3-октавным полосам (было / стало / дельта), RMS-дельта
по всему диапазону и график. Это и есть Фаза 2 дорожной карты (A/B delta),
только пока в терминале вместо HUD в очках — логика та же самая.

## Тесты

```bash
pytest tests/test_dsp.py -v
```

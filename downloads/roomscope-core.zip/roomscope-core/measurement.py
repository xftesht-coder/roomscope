"""ROOM·SCOPE — Модуль реального измерения.

Проигрывает test sweep через колонки и одновременно пишет отклик комнаты
через микрофон (UMIK-1). Пока UMIK-1 едет — работает в синтетическом
режиме: "запись" эмулируется свёрткой sweep с модельным IR комнаты, чтобы
весь пайплайн (impulse_response → octave_smoothing → peq_calculator) можно
было гонять и проверять уже сейчас.

Переключение на реальное железо — правка одного поля в config.json:
  "mode": "synthetic" -> "real"
и, при необходимости, "input_device"/"output_device" на индекс UMIK-1
(смотри `python measurement.py --list-devices`).
"""
import argparse
import json
import os

import numpy as np
import soundfile as sf

from dsp.swept_sine import generate_swept_sine, save_to_wav

DEFAULT_CONFIG = {
    "sample_rate": 48000,
    "f_start": 20.0,
    "f_end": 20000.0,
    "duration": 10.0,
    "amplitude": 0.9,
    "channels_in": 1,
    "input_device": None,   # None = устройство по умолчанию; индекс UMIK-1 — после `--list-devices`
    "output_device": None,  # None = устройство по умолчанию (ваши колонки)
    "mode": "synthetic",    # "synthetic" | "real"
}


def load_config(path="config.json"):
    """Читает config.json, если он существует и не пуст; иначе — дефолты."""
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        with open(path, "r", encoding="utf-8") as f:
            user_cfg = json.load(f)
        cfg.update(user_cfg)
    return cfg


def list_input_devices():
    """Печатает список входных аудиоустройств (нужно найти индекс UMIK-1)."""
    import sounddevice as sd
    devices = sd.query_devices()
    print("Доступные устройства ввода:")
    for i, d in enumerate(devices):
        if d["max_input_channels"] > 0:
            print(f"  [{i}] {d['name']}  (in={d['max_input_channels']}, "
                  f"sr={d['default_samplerate']:.0f} Hz)")
    return devices


def record_real(sweep, cfg):
    """Играет sweep и одновременно пишет с микрофона (UMIK-1)."""
    import sounddevice as sd

    sr = int(cfg["sample_rate"])
    device = (cfg["input_device"], cfg["output_device"])
    if device != (None, None):
        sd.default.device = device

    label = f"устройство #{cfg['input_device']}" if cfg["input_device"] is not None else "устройство по умолчанию"
    print(f"🎙  Проигрываю sweep и пишу через {label}...")

    recording = sd.playrec(
        sweep.reshape(-1, 1),
        samplerate=sr,
        channels=cfg["channels_in"],
        blocking=True,
    )
    sd.wait()
    return recording.flatten()


def record_synthetic(sweep, cfg):
    """Синтетический прогон без железа: эмулируем отклик модельной комнаты."""
    print("🧪 Синтетический режим (UMIK-1 ещё не подключён) — эмулирую отклик комнаты.")
    sr = int(cfg["sample_rate"])

    # простая модельная комната: прямой звук + пара поздних отражений + шум пола
    ir_len = int(0.05 * sr)
    ir_model = np.zeros(ir_len)
    ir_model[0] = 1.0
    ir_model[int(0.008 * sr)] = 0.35
    ir_model[int(0.021 * sr)] = 0.20

    recording = np.convolve(sweep, ir_model, mode="full")[: len(sweep)]
    recording = recording + np.random.normal(0, 0.001, size=recording.shape)
    return recording.astype(np.float64)


def run_measurement(config_path="config.json", output_path="room_recording.wav"):
    cfg = load_config(config_path)

    sweep = generate_swept_sine(
        f_start=cfg["f_start"],
        f_end=cfg["f_end"],
        duration=cfg["duration"],
        sample_rate=cfg["sample_rate"],
        amplitude=cfg["amplitude"],
    )
    save_to_wav(sweep, "test_sweep.wav", sample_rate=cfg["sample_rate"])

    if cfg["mode"] == "real":
        recording = record_real(sweep, cfg)
    else:
        recording = record_synthetic(sweep, cfg)

    max_val = np.max(np.abs(recording))
    if max_val > 0:
        recording = recording / max_val * 0.9
    sf.write(output_path, recording, int(cfg["sample_rate"]), subtype="PCM_24")

    print(f"✅ Запись комнаты сохранена: {output_path}  (режим: {cfg['mode']})")
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ROOM·SCOPE — измерение комнаты (sweep + запись)")
    parser.add_argument("--config", default="config.json", help="путь к config.json")
    parser.add_argument("--out", default="room_recording.wav", help="куда сохранить запись")
    parser.add_argument("--list-devices", action="store_true", help="показать список аудиоустройств и выйти")
    args = parser.parse_args()

    if args.list_devices:
        list_input_devices()
    else:
        run_measurement(args.config, args.out)

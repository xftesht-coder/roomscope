"""ROOM·SCOPE — деконволюция IR (метод Farina)"""
import argparse
import os

import numpy as np
from scipy.fft import fft, ifft
import soundfile as sf
from dsp.swept_sine import generate_swept_sine

def generate_inverse_filter(sweep, sample_rate=48000.0, f_start=20.0, f_end=20000.0):
    N = len(sweep)
    duration = N / sample_rate
    K = np.log(f_end / f_start) / duration
    t = np.arange(N) / sample_rate
    compensation = np.exp(K * t)
    compensation = compensation / compensation.max()
    sweep_compensated = sweep * compensation
    inverse = np.flip(sweep_compensated)
    energy = np.sqrt(np.sum(inverse ** 2))
    if energy > 0:
        inverse = inverse / energy * np.sqrt(N)
    return inverse

def deconvolve(recorded, inverse_filter):
    N = len(recorded) + len(inverse_filter) - 1
    N_fft = int(2 ** np.ceil(np.log2(N)))
    X = fft(recorded, n=N_fft)
    H_inv = fft(inverse_filter, n=N_fft)
    ir = np.real(ifft(X * H_inv))
    return ir[:N]

def calculate_ir_metrics(ir, sample_rate=48000.0):
    peak_idx = np.argmax(np.abs(ir))
    peak_time = peak_idx / sample_rate
    peak_value = np.abs(ir[peak_idx])
    ir_abs = np.abs(ir[peak_idx:])
    ir_db = 20 * np.log10(ir_abs / ir_abs[0] + 1e-10) if ir_abs[0] > 0 else np.zeros_like(ir_abs)
    below_60 = np.where(ir_db < -60)[0]
    rt60 = below_60[0] / sample_rate if len(below_60) > 0 else len(ir_abs) / sample_rate
    noise_floor = np.sqrt(np.mean(ir[-len(ir)//10:] ** 2))
    dynamic_range_db = 20 * np.log10(peak_value / noise_floor) if noise_floor > 0 else 0.0
    return {
        "peak_time_sec": round(peak_time, 6),
        "rt60_sec": round(rt60, 6),
        "dynamic_range_db": round(dynamic_range_db, 2),
    }

def save_ir(ir, filepath, sample_rate=48000.0):
    max_val = np.max(np.abs(ir))
    ir_normalized = ir / max_val * 0.9 if max_val > 0 else ir
    sf.write(filepath, ir_normalized, int(sample_rate), subtype="PCM_24")
    print(f"IR saved: {filepath}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="ROOM·SCOPE — деконволюция IR методом Farina. "
                    "Без --recording гоняет самотест (sweep против самого себя)."
    )
    parser.add_argument("--sweep", default="test_sweep.wav", help="файл сыгранного sweep (для --recording)")
    parser.add_argument("--recording", default=None, help="файл записи комнаты (из measurement.py); "
                         "если не указан — самотест на синтетическом sweep")
    parser.add_argument("--out", default="test_ir.wav", help="куда сохранить импульсный отклик")
    parser.add_argument("--f-start", type=float, default=20.0)
    parser.add_argument("--f-end", type=float, default=20000.0)
    args = parser.parse_args()

    print("=" * 60)
    print("ROOM·SCOPE — Деконволюция IR")
    print("=" * 60)

    if args.recording:
        if not os.path.exists(args.sweep):
            raise SystemExit(f"Не найден файл sweep: {args.sweep} (сначала запусти measurement.py)")
        sweep, sr = sf.read(args.sweep)
        recording, sr_rec = sf.read(args.recording)
        if sr_rec != sr:
            raise SystemExit(f"Частоты дискретизации не совпадают: sweep={sr} Hz, recording={sr_rec} Hz")
        print(f"Sweep: {args.sweep} ({len(sweep)} samples, {sr} Hz)")
        print(f"Recording: {args.recording} ({len(recording)} samples, {sr_rec} Hz)")
        inverse = generate_inverse_filter(sweep, sample_rate=sr, f_start=args.f_start, f_end=args.f_end)
        ir = deconvolve(recording, inverse)
        metrics = calculate_ir_metrics(ir, sample_rate=sr)
        for k, v in metrics.items():
            print(f"  {k}: {v}")
        save_ir(ir, args.out, sample_rate=sr)
    else:
        sweep = generate_swept_sine(f_start=args.f_start, f_end=args.f_end, duration=10, sample_rate=48000)
        inverse = generate_inverse_filter(sweep, sample_rate=48000, f_start=args.f_start, f_end=args.f_end)
        ir = deconvolve(sweep, inverse)
        metrics = calculate_ir_metrics(ir, sample_rate=48000)
        for k, v in metrics.items():
            print(f"  {k}: {v}")
        save_ir(ir, args.out, sample_rate=48000)

    print("✅ IR готов")

import argparse
import numpy as np
from scipy.signal import find_peaks
import json
import soundfile as sf
from dsp.octave_smoothing import calculate_frequency_response

def calculate_peq_filters(centers, smoothed_db, threshold_db=3.0, max_filters=5):
    inverted_db = -smoothed_db
    peaks, properties = find_peaks(inverted_db, prominence=threshold_db, height=threshold_db)
    peak_heights = properties['prominences']
    sorted_indices = np.argsort(peak_heights)[::-1]
    filters = []
    for i in sorted_indices[:max_filters]:
        peak_idx = peaks[i]
        freq = float(centers[peak_idx])
        gain = float(-smoothed_db[peak_idx])
        peak_val = inverted_db[peak_idx]
        half_power = peak_val - 3.0
        left_idx = peak_idx
        while left_idx > 0 and inverted_db[left_idx] > half_power:
            left_idx -= 1
        right_idx = peak_idx
        while right_idx < len(inverted_db) - 1 and inverted_db[right_idx] > half_power:
            right_idx += 1
        bw_freq = centers[right_idx] - centers[left_idx]
        q = freq / bw_freq if bw_freq > 0 else 1.41
        q = np.clip(q, 0.5, 10.0)
        filters.append({'type': 'peak', 'freq_hz': round(freq, 1), 'gain_db': round(gain, 1), 'q_factor': round(q, 2)})
    filters.sort(key=lambda x: x['freq_hz'])
    return filters

def save_profile_json(filters, centers=None, smoothed_db=None, filepath='profile.json', label=None):
    """Сохраняет профиль позиции: и найденные PEQ-фильтры, и саму АЧХ (centers/smoothed_db).

    Кривая АЧХ нужна для сравнения двух позиций между собой (compare_profiles.py) —
    одних только найденных пиков для этого недостаточно.
    """
    profile = {
        'roomscope_version': '0.2',
        'label': label,
        'target': 'flat',
        'microphone': 'UMIK-1 (simulated)',
        'peq_filters': filters,
        'response': {
            'centers_hz': [float(c) for c in centers] if centers is not None else None,
            'smoothed_db': [float(v) for v in smoothed_db] if smoothed_db is not None else None,
        },
    }
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(profile, f, indent=2, ensure_ascii=False)
    print('Profile saved: ' + filepath)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='ROOM·SCOPE — расчёт АЧХ и PEQ-фильтров из импульсного отклика')
    parser.add_argument('--ir', default='test_ir.wav', help='файл импульсного отклика (WAV)')
    parser.add_argument('--out', default='profile.json', help='куда сохранить профиль')
    parser.add_argument('--label', default=None, help='название позиции, напр. "seat_A / speaker default"')
    parser.add_argument('--threshold-db', type=float, default=2.0, help='порог для детекции пиков, дБ')
    parser.add_argument('--max-filters', type=int, default=5, help='максимум PEQ-фильтров')
    args = parser.parse_args()

    print('=' * 60)
    print('ROOM-SCOPE - PEQ Processing')
    print('=' * 60)
    ir, sr = sf.read(args.ir)
    print('IR analysis: ' + str(len(ir)) + ' samples, ' + str(sr) + ' Hz')
    smoothed_db, centers = calculate_frequency_response(ir, sr, smooth=True)
    filters = calculate_peq_filters(centers, smoothed_db, threshold_db=args.threshold_db, max_filters=args.max_filters)
    print('Filters found: ' + str(len(filters)))
    for i, f in enumerate(filters, 1):
        print('  ' + str(i) + '. Freq: ' + str(f['freq_hz']) + ' Hz | Gain: ' + str(f['gain_db']) + ' dB | Q: ' + str(f['q_factor']))
    if not filters:
        print('  (No peaks detected. Response is within tolerance).')
    save_profile_json(filters, centers=centers, smoothed_db=smoothed_db, filepath=args.out, label=args.label)
    print('=' * 60)